{
  "name": "Math PayQuiz Game",
  "short_name": "PayQuiz",
  "start_url": "/",
  "display": "standalone",
  "background_color": "#ffffff",
  "theme_color": "#50A3A4",
  "icons": [
    {
      "src": "img/192.png",
      "sizes": "192x192",
      "type": "image/png"
    },
    {
      "src": "img/512.png",
      "sizes": "512x512",
      "type": "image/png"
    }
  ]
}